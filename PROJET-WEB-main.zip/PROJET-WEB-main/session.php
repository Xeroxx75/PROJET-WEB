<?php

session_start();
$mail = $_SESSION['email'];
echo $mail;




?>
